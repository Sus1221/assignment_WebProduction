-- phpMyAdmin SQL Dump
-- version 4.2.9
-- http://www.phpmyadmin.net
--
-- Värd: localhost
-- Tid vid skapande: 13 feb 2015 kl 14:31
-- Serverversion: 5.6.20
-- PHP-version: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databas: `webbproduktion2`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `footer`
--

CREATE TABLE IF NOT EXISTS `footer` (
  `name` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `postalcode` int(11) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `footer`
--

INSERT INTO `footer` (`name`, `street`, `postalcode`, `city`, `phone`, `email`, `info`, `created`) VALUES
('aedrh', 'aderh', 0, 'ah', 'ha', NULL, 'aher', '2015-01-23 15:00:49'),
('sus', 'jon', 23456, '3rahn', '35474', NULL, 'sudansrg', '2015-01-23 15:00:49'),
('Tåg i skåne idag', 'låtsasvägen 5', 34567, 'olods', '015-65201', NULL, 'blatag@mail.se', '2015-01-23 15:00:49'),
('katten j', 'kattgatan 5', 34567, 'katthamn', '042-251203', 'katt@hatt.se', NULL, '2015-01-23 15:00:49'),
('aedrh', 'aerh', 0, 'rhe', 'reh', 'rhe', NULL, '2015-01-23 15:24:59'),
('esrh', 'reh', 0, 'aerh', 'rhe', 'rhe', NULL, '2015-01-23 15:25:16'),
('tågåkeriet', 'skördevägen 7', 25695, 'olofström', '048-0251425', 'katt@hatt.fisk', NULL, '2015-01-26 14:26:57'),
('Kattälskarna', 'kattvägen 3', 15548, 'malmö', '025-6231425', 'katt@fnatt.se', NULL, '2015-01-27 10:30:58'),
('hundälskarna', 'hundv. 45', 23454, 'lund', '067-45642375', 'hund@ben.se', NULL, '2015-01-27 10:34:03'),
('Susannes skoaffär', 'Lofotsvägen 56', 34565, 'lund', '025-1523251', 'ot@sko.se', NULL, '2015-01-27 12:06:47'),
('tågskåne idag', 'kattstigen 12', 34565, 'lund', '052-3251425', 'tagskane@tag.se', NULL, '2015-01-27 14:46:37'),
('tåg i skåne idag!', 'skördevägen 7', 29162, 'lund', '025-2536251', 'sus@mail.se', NULL, '2015-01-27 14:50:37'),
('kattens tåg', 'lokvägen 4', 24565, 'kristianstad', '015-5230125', 'katt@klo.se', NULL, '2015-01-28 17:14:30'),
('asrhaes', 'aedrhaerh', 0, 'adrh', 'aerthn', 'aedrthb', NULL, '2015-02-08 15:06:13'),
('tågskåne Idag', 'tåggatan 3', 15845, 'lund', '041-5236251', 'åtg@lok.se', NULL, '2015-02-08 15:06:43'),
('ertyk', 'syrkj', 0, 'sykrt', 'sky', 'sky', NULL, '2015-02-08 15:21:51'),
('', '', 0, '', '', '', NULL, '2015-02-08 15:26:18'),
('sus', 'jöns', 0, '355', '0-4', 'd@f.se', NULL, '2015-02-08 15:26:40'),
('tågtidning', 'hejvägen 3', 15241, 'lund', '012-3521254', 'tag.se', NULL, '2015-02-08 17:40:14');

-- --------------------------------------------------------

--
-- Tabellstruktur `images`
--

CREATE TABLE IF NOT EXISTS `images` (
`iid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `alt` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `uploaded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellstruktur `menu_links`
--

CREATE TABLE IF NOT EXISTS `menu_links` (
`ml_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `plid` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumpning av Data i tabell `menu_links`
--

INSERT INTO `menu_links` (`ml_id`, `title`, `path`, `weight`, `plid`) VALUES
(2, 'sdfdsf', 'sdfsdfsfs', 0, NULL),
(3, 'Hejsan', 'katt', 1, NULL),
(4, 'utflykter', 'outings', 6, NULL),
(5, 'tågtragiken', 'traintragic', 0, NULL),
(6, 'skånetragiken', 'scania_tragic', 9, 5),
(7, 'katt på tåg', 'catOnTrain', 2, 4),
(8, 'hejsan', 'hello', 3, 3),
(9, 'trest', 'tresta', 0, 2),
(10, 'lokföraren', 'traindriver', 0, 8);

-- --------------------------------------------------------

--
-- Tabellstruktur `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
`pid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `img_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `video_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Dumpning av Data i tabell `pages`
--

INSERT INTO `pages` (`pid`, `title`, `body`, `img_id`, `user_id`, `video_id`, `created`) VALUES
(11, 'att lägga en järnvägsväxel', 'jan', NULL, 1, NULL, '2015-01-29 07:53:15'),
(12, 'stins på 2001-talet', 'aerthaer', NULL, 1, NULL, '2015-02-08 15:53:17'),
(13, 'dressin genom österlen', 'aetrhaeh', NULL, 1, NULL, '2015-02-08 15:54:30'),
(15, 'orientexpressen genom skåne', 'aerhaerhearherh', NULL, 1, NULL, '2015-02-09 14:54:58'),
(16, 'julkrysset', 'här med', NULL, 1, NULL, '2015-02-09 14:55:46'),
(17, 'Nu väntar jag på rätt avgång', 'Bla ', NULL, 1, NULL, '2015-02-10 19:45:57'),
(18, 'X31 - en resa', 'Bacon ipsum dolor amet ball tip filet mignon sausage landjaeger, pork chop ham turkey venison cupim short ribs. Pork cow ribeye sausage swine short loin tongue. Short ribs rump tail landjaeger biltong cow. Bresaola fatback short loin doner strip steak andouille chuck ham meatball ball tip drumstick turducken picanha prosciutto. Beef ribs tenderloin pork loin brisket shankle bresaola drumstick.', NULL, 1, NULL, '2015-02-10 19:48:33'),
(19, 'den långa resan', 'Bacon ipsum dolor amet ball tip filet mignon sausage landjaeger, pork chop ham turkey venison cupim short ribs. Pork cow ribeye sausage swine short loin tongue. Short ribs rump tail landjaeger biltong cow. Bresaola fatback short loin doner strip steak andouille chuck ham meatball ball tip drumstick turducken picanha prosciutto. Beef ribs tenderloin pork loin brisket shankle bresaola drumstick.', NULL, 1, NULL, '2015-02-10 19:48:44'),
(20, 'ånglokens värld', 'Bacon ipsum dolor amet ball tip filet mignon sausage landjaeger, pork chop ham turkey venison cupim short ribs. Pork cow ribeye sausage swine short loin tongue. Short ribs rump tail landjaeger biltong cow. Bresaola fatback short loin doner strip steak andouille chuck ham meatball ball tip drumstick turducken picanha prosciutto. Beef ribs tenderloin pork loin brisket shankle bresaola drumstick.', NULL, 1, NULL, '2015-02-10 19:48:56'),
(21, 'katten i den gamla tågvagnen', 'Bacon ipsum dolor amet ball tip filet mignon sausage landjaeger, pork chop ham turkey venison cupim short ribs. Pork cow ribeye sausage swine short loin tongue. Short ribs rump tail landjaeger biltong cow. Bresaola fatback short loin doner strip steak andouille chuck ham meatball ball tip drumstick turducken picanha prosciutto. Beef ribs tenderloin pork loin brisket shankle bresaola drumstick.', NULL, 1, NULL, '2015-02-10 19:49:09'),
(22, 'U-45 - det tyska sekelloket', 'Bacon ipsum dolor amet ball tip filet mignon sausage landjaeger, pork chop ham turkey venison cupim short ribs. Pork cow ribeye sausage swine short loin tongue. Short ribs rump tail landjaeger biltong cow. Bresaola fatback short loin doner strip steak andouille chuck ham meatball ball tip drumstick turducken picanha prosciutto. Beef ribs tenderloin pork loin brisket shankle bresaola drumstick.', NULL, 1, NULL, '2015-02-10 19:49:40'),
(23, 'på resa med 3 3-åringar genom sverige', 'Bacon ipsum dolor amet ball tip filet mignon sausage landjaeger, pork chop ham turkey venison cupim short ribs. Pork cow ribeye sausage swine short loin tongue. Short ribs rump tail landjaeger biltong cow. Bresaola fatback short loin doner strip steak andouille chuck ham meatball ball tip drumstick turducken picanha prosciutto. Beef ribs tenderloin pork loin brisket shankle bresaola drumstick.', NULL, 1, NULL, '2015-02-10 19:50:02'),
(24, 'hamburg - malmö tor.', 'Bacon ipsum dolor amet ball tip filet mignon sausage landjaeger, pork chop ham turkey venison cupim short ribs. Pork cow ribeye sausage swine short loin tongue. Short ribs rump tail landjaeger biltong cow. Bresaola fatback short loin doner strip steak andouille chuck ham meatball ball tip drumstick turducken picanha prosciutto. Beef ribs tenderloin pork loin brisket shankle bresaola drumstick.', NULL, 1, NULL, '2015-02-10 19:50:15'),
(25, 'Veckans tävling', 'Bacon ipsum dolor amet ball tip filet mignon sausage landjaeger, pork chop ham turkey venison cupim short ribs. Pork cow ribeye sausage swine short loin tongue. Short ribs rump tail landjaeger biltong cow. Bresaola fatback short loin doner strip steak andouille chuck ham meatball ball tip drumstick turducken picanha prosciutto. Beef ribs tenderloin pork loin brisket shankle bresaola drumstick.', NULL, 1, NULL, '2015-02-10 19:50:27'),
(26, 'bildtävling2', 'Bacon ipsum dolor amet ball tip filet mignon sausage landjaeger, pork chop ham turkey venison cupim short ribs. Pork cow ribeye sausage swine short loin tongue. Short ribs rump tail landjaeger biltong cow. Bresaola fatback short loin doner strip steak andouille chuck ham meatball ball tip drumstick turducken picanha prosciutto. Beef ribs tenderloin pork loin brisket shankle bresaola drumstick.20', NULL, 1, NULL, '2015-02-10 19:50:34');

-- --------------------------------------------------------

--
-- Tabellstruktur `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`uid` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `description` text,
  `joined` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumpning av Data i tabell `users`
--

INSERT INTO `users` (`uid`, `fname`, `lname`, `email`, `pass`, `description`, `joined`) VALUES
(1, 'susanne', 'jönsson', 'susanne881221@hotmail.com', 'hej', 'det är jag som', '2015-01-29 07:46:35');

-- --------------------------------------------------------

--
-- Tabellstruktur `video`
--

CREATE TABLE IF NOT EXISTS `video` (
`vid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `alt` varchar(255) DEFAULT NULL,
  `description` text,
  `user_id` int(11) NOT NULL,
  `uploaded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `images`
--
ALTER TABLE `images`
 ADD PRIMARY KEY (`iid`), ADD KEY `user_id` (`user_id`);

--
-- Index för tabell `menu_links`
--
ALTER TABLE `menu_links`
 ADD PRIMARY KEY (`ml_id`), ADD KEY `plid` (`plid`);

--
-- Index för tabell `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`pid`), ADD KEY `user_id` (`user_id`), ADD KEY `img_id` (`img_id`), ADD KEY `video_id` (`video_id`);

--
-- Index för tabell `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`uid`), ADD UNIQUE KEY `email` (`email`);

--
-- Index för tabell `video`
--
ALTER TABLE `video`
 ADD PRIMARY KEY (`vid`), ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT för dumpade tabeller
--

--
-- AUTO_INCREMENT för tabell `images`
--
ALTER TABLE `images`
MODIFY `iid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT för tabell `menu_links`
--
ALTER TABLE `menu_links`
MODIFY `ml_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT för tabell `pages`
--
ALTER TABLE `pages`
MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT för tabell `users`
--
ALTER TABLE `users`
MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT för tabell `video`
--
ALTER TABLE `video`
MODIFY `vid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Restriktioner för dumpade tabeller
--

--
-- Restriktioner för tabell `images`
--
ALTER TABLE `images`
ADD CONSTRAINT `images_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`uid`);

--
-- Restriktioner för tabell `menu_links`
--
ALTER TABLE `menu_links`
ADD CONSTRAINT `menu_links_ibfk_1` FOREIGN KEY (`plid`) REFERENCES `menu_links` (`ml_id`),
ADD CONSTRAINT `menu_links_ibfk_2` FOREIGN KEY (`plid`) REFERENCES `menu_links` (`ml_id`),
ADD CONSTRAINT `menu_links_ibfk_3` FOREIGN KEY (`plid`) REFERENCES `menu_links` (`ml_id`);

--
-- Restriktioner för tabell `pages`
--
ALTER TABLE `pages`
ADD CONSTRAINT `pages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`uid`),
ADD CONSTRAINT `pages_ibfk_2` FOREIGN KEY (`img_id`) REFERENCES `images` (`iid`),
ADD CONSTRAINT `pages_ibfk_3` FOREIGN KEY (`video_id`) REFERENCES `video` (`vid`);

--
-- Restriktioner för tabell `video`
--
ALTER TABLE `video`
ADD CONSTRAINT `video_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`uid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

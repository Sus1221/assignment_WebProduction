-- phpMyAdmin SQL Dump
-- version 4.2.9
-- http://www.phpmyadmin.net
--
-- Värd: localhost
-- Tid vid skapande: 19 feb 2015 kl 13:36
-- Serverversion: 5.6.20
-- PHP-version: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databas: `webbproduktion2`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'traintypes'),
(2, 'electrical'),
(3, 'diesel'),
(4, 'outings'),
(5, 'readercontact');

-- --------------------------------------------------------

--
-- Tabellstruktur `footer`
--

CREATE TABLE IF NOT EXISTS `footer` (
  `name` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `postalcode` int(11) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `footer`
--

INSERT INTO `footer` (`name`, `street`, `postalcode`, `city`, `phone`, `email`, `created`) VALUES
('Tåg i skåne idag!', 'lugnets väg 45', 34598, 'Kattarp', '026 - 301 25 12', 'info@tagiskane.se', '2015-02-18 10:26:06');

-- --------------------------------------------------------

--
-- Tabellstruktur `images`
--

CREATE TABLE IF NOT EXISTS `images` (
`iid` int(11) NOT NULL,
  `path` varchar(1000) NOT NULL,
  `user_id` int(11) NOT NULL,
  `uploaded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

--
-- Dumpning av Data i tabell `images`
--

INSERT INTO `images` (`iid`, `path`, `user_id`, `uploaded`) VALUES
(11, 'http://www.engelholm.se/ImageVaultFiles/id_3816/cf_1792/IMG_0245NY.JPG', 1, '2015-02-18 10:28:16'),
(12, 'http://www.jtj.org/jtj_nytt/artiklar/mallet_8/mallet_8_jtj_100606_013.jpg', 1, '2015-02-18 10:30:20'),
(13, 'http://www.kuehn-digital.de/mo/images/produkte/32080-web.jpg', 1, '2015-02-18 10:31:12'),
(14, 'https://c2.staticflickr.com/8/7043/7013535913_da5da8d294_z.jpg', 1, '2015-02-18 10:31:54'),
(15, 'http://www.arriva.se/sites/default/files/styles/469x304/public/galleries/ptag.jpg?itok=GzRCSHwI', 1, '2015-02-18 10:32:34'),
(16, 'http://upload.wikimedia.org/wikipedia/commons/thumb/d/da/X2000_exteri%C3%B6r_vid_k%C3%B6rning_i_Tormestorp_SJ_AB.jpg/300px-X2000_exteri%C3%B6r_vid_k%C3%B6rning_i_Tormestorp_SJ_AB.jpg', 1, '2015-02-18 10:33:20'),
(17, 'http://upload.wikimedia.org/wikipedia/commons/thumb/4/45/Draisine-templin.jpg/250px-Draisine-templin.jpg', 1, '2015-02-18 10:34:15'),
(18, 'http://1.bp.blogspot.com/-vEwlS02z16Y/UgEi2c_i49I/AAAAAAAAAvw/UGvebbaS45I/s1600/js_130801_0832_450b.jpg', 1, '2015-02-18 10:34:56'),
(19, 'http://upload.wikimedia.org/wikipedia/commons/8/8a/Malm%C3%B6_C,_banhallen.jpg', 1, '2015-02-18 10:35:27'),
(20, 'http://sverigesradio.se/sida/images/87/2519246_1200_675.jpg?preset=article', 1, '2015-02-18 10:36:30'),
(21, 'http://cdn02.nyheter24.se/e5564ce00802021d01/old/2010/11/21/sy38c2a8.jpg', 1, '2015-02-18 10:37:22'),
(22, 'http://img.tradera.net/images/816/200751816_2d5e755d-1838-4c04-a66d-8ddd0867dff4.jpg', 1, '2015-02-18 10:38:01');

-- --------------------------------------------------------

--
-- Tabellstruktur `menu_links`
--

CREATE TABLE IF NOT EXISTS `menu_links` (
`ml_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `plid` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumpning av Data i tabell `menu_links`
--

INSERT INTO `menu_links` (`ml_id`, `title`, `path`, `weight`, `plid`) VALUES
(2, 'fordonstyper', 'traintypes', 0, NULL),
(3, 'utflyktstips', 'outings', 1, NULL),
(4, 'läsarkontakt', 'readercontact', 2, NULL),
(5, 'diesel', 'diesel', 0, 2),
(6, 'el', 'electrical', 1, 2);

-- --------------------------------------------------------

--
-- Tabellstruktur `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
`pid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `img_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `catId` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumpning av Data i tabell `pages`
--

INSERT INTO `pages` (`pid`, `title`, `body`, `img_id`, `created`, `catId`) VALUES
(1, 'Tävling v45', 'Nu är det dags att svara på veckans fråga. I potten ligger två biljetter till Järnvägsmuseet i Ängelholm. Pork loin chuck short ribs pastrami, landjaeger swine tail tongue beef kielbasa ham ground round. Doner pancetta sausage spare ribs jerky. Swine cow jowl, corned beef ribeye leberkas biltong short loin beef strip steak jerky meatball cupim tenderloin. Short loin kevin pork loin chuck, alcatra venison filet mignon drumstick shankle bacon. Pastrami picanha pork loin meatball bresaola meatloaf frankfurter spare ribs leberkas kielbasa chicken shankle. Pork ground round tenderloin beef kevin pork loin tail cow tongue ribeye ham prosciutto jowl alcatra. Brisket swine tail landjaeger andouille beef pig beef ribs pastrami kevin bacon.', 11, '2015-02-18 10:28:16', 5),
(2, 'X8 - loket som drog kol genom Skåne på 1920-talet', 'Pork loin chuck short ribs pastrami, landjaeger swine tail tongue beef kielbasa ham ground round. Doner pancetta sausage spare ribs jerky. Swine cow jowl, corned beef ribeye leberkas biltong short loin beef strip steak jerky meatball cupim tenderloin. Short loin kevin pork loin chuck, alcatra venison filet mignon drumstick shankle bacon. Pastrami picanha pork loin meatball bresaola meatloaf frankfurter spare ribs leberkas kielbasa chicken shankle. Pork ground round tenderloin beef kevin pork loin tail cow tongue ribeye ham prosciutto jowl alcatra. Brisket swine tail landjaeger andouille beef pig beef ribs pastrami kevin bacon.', 12, '2015-02-18 10:30:20', 3),
(3, 'Modernaste dieselloket i Skåne just nu!', 'Pork loin chuck short ribs pastrami, landjaeger swine tail tongue beef kielbasa ham ground round. Doner pancetta sausage spare ribs jerky. Swine cow jowl, corned beef ribeye leberkas biltong short loin beef strip steak jerky meatball cupim tenderloin. Short loin kevin pork loin chuck, alcatra venison filet mignon drumstick shankle bacon. Pastrami picanha pork loin meatball bresaola meatloaf frankfurter spare ribs leberkas kielbasa chicken shankle. Pork ground round tenderloin beef kevin pork loin tail cow tongue ribeye ham prosciutto jowl alcatra. Brisket swine tail landjaeger andouille beef pig beef ribs pastrami kevin bacon.', 13, '2015-02-18 10:31:12', 3),
(4, 'Vanligaste tåget i skåne!', 'Pork loin chuck short ribs pastrami, landjaeger swine tail tongue beef kielbasa ham ground round. Doner pancetta sausage spare ribs jerky. Swine cow jowl, corned beef ribeye leberkas biltong short loin beef strip steak jerky meatball cupim tenderloin. Short loin kevin pork loin chuck, alcatra venison filet mignon drumstick shankle bacon. Pastrami picanha pork loin meatball bresaola meatloaf frankfurter spare ribs leberkas kielbasa chicken shankle. Pork ground round tenderloin beef kevin pork loin tail cow tongue ribeye ham prosciutto jowl alcatra. Brisket swine tail landjaeger andouille beef pig beef ribs pastrami kevin bacon.', 14, '2015-02-18 10:31:54', 2),
(5, 'Skånskaste av de skånska tågen', 'Pork loin chuck short ribs pastrami, landjaeger swine tail tongue beef kielbasa ham ground round. Doner pancetta sausage spare ribs jerky. Swine cow jowl, corned beef ribeye leberkas biltong short loin beef strip steak jerky meatball cupim tenderloin. Short loin kevin pork loin chuck, alcatra venison filet mignon drumstick shankle bacon. Pastrami picanha pork loin meatball bresaola meatloaf frankfurter spare ribs leberkas kielbasa chicken shankle. Pork ground round tenderloin beef kevin pork loin tail cow tongue ribeye ham prosciutto jowl alcatra. Brisket swine tail landjaeger andouille beef pig beef ribs pastrami kevin bacon.', 15, '2015-02-18 10:32:34', 2),
(6, 'snabbtåg i skåne', 'Pork loin chuck short ribs pastrami, landjaeger swine tail tongue beef kielbasa ham ground round. Doner pancetta sausage spare ribs jerky. Swine cow jowl, corned beef ribeye leberkas biltong short loin beef strip steak jerky meatball cupim tenderloin. Short loin kevin pork loin chuck, alcatra venison filet mignon drumstick shankle bacon. Pastrami picanha pork loin meatball bresaola meatloaf frankfurter spare ribs leberkas kielbasa chicken shankle. Pork ground round tenderloin beef kevin pork loin tail cow tongue ribeye ham prosciutto jowl alcatra. Brisket swine tail landjaeger andouille beef pig beef ribs pastrami kevin bacon.', 16, '2015-02-18 10:33:20', 1),
(7, 'Dressin i höst!', 'Pork loin chuck short ribs pastrami, landjaeger swine tail tongue beef kielbasa ham ground round. Doner pancetta sausage spare ribs jerky. Swine cow jowl, corned beef ribeye leberkas biltong short loin beef strip steak jerky meatball cupim tenderloin. Short loin kevin pork loin chuck, alcatra venison filet mignon drumstick shankle bacon. Pastrami picanha pork loin meatball bresaola meatloaf frankfurter spare ribs leberkas kielbasa chicken shankle. Pork ground round tenderloin beef kevin pork loin tail cow tongue ribeye ham prosciutto jowl alcatra. Brisket swine tail landjaeger andouille beef pig beef ribs pastrami kevin bacon.', 17, '2015-02-18 10:34:15', 4),
(8, 'Med kolflingor i luggen...', 'Pork loin chuck short ribs pastrami, landjaeger swine tail tongue beef kielbasa ham ground round. Doner pancetta sausage spare ribs jerky. Swine cow jowl, corned beef ribeye leberkas biltong short loin beef strip steak jerky meatball cupim tenderloin. Short loin kevin pork loin chuck, alcatra venison filet mignon drumstick shankle bacon. Pastrami picanha pork loin meatball bresaola meatloaf frankfurter spare ribs leberkas kielbasa chicken shankle. Pork ground round tenderloin beef kevin pork loin tail cow tongue ribeye ham prosciutto jowl alcatra. Brisket swine tail landjaeger andouille beef pig beef ribs pastrami kevin bacon.', 18, '2015-02-18 10:34:56', 4),
(9, 'Trainspotting på malmö c', 'Pork loin chuck short ribs pastrami, landjaeger swine tail tongue beef kielbasa ham ground round. Doner pancetta sausage spare ribs jerky. Swine cow jowl, corned beef ribeye leberkas biltong short loin beef strip steak jerky meatball cupim tenderloin. Short loin kevin pork loin chuck, alcatra venison filet mignon drumstick shankle bacon. Pastrami picanha pork loin meatball bresaola meatloaf frankfurter spare ribs leberkas kielbasa chicken shankle. Pork ground round tenderloin beef kevin pork loin tail cow tongue ribeye ham prosciutto jowl alcatra. Brisket swine tail landjaeger andouille beef pig beef ribs pastrami kevin bacon.', 19, '2015-02-18 10:35:27', 4),
(10, 'Sveriges transporthjälte - RC!', 'Pork loin chuck short ribs pastrami, landjaeger swine tail tongue beef kielbasa ham ground round. Doner pancetta sausage spare ribs jerky. Swine cow jowl, corned beef ribeye leberkas biltong short loin beef strip steak jerky meatball cupim tenderloin. Short loin kevin pork loin chuck, alcatra venison filet mignon drumstick shankle bacon. Pastrami picanha pork loin meatball bresaola meatloaf frankfurter spare ribs leberkas kielbasa chicken shankle. Pork ground round tenderloin beef kevin pork loin tail cow tongue ribeye ham prosciutto jowl alcatra. Brisket swine tail landjaeger andouille beef pig beef ribs pastrami kevin bacon.', 20, '2015-02-18 10:36:30', 1),
(11, 'jultävling!', 'Pork loin chuck short ribs pastrami, landjaeger swine tail tongue beef kielbasa ham ground round. Doner pancetta sausage spare ribs jerky. Swine cow jowl, corned beef ribeye leberkas biltong short loin beef strip steak jerky meatball cupim tenderloin. Short loin kevin pork loin chuck, alcatra venison filet mignon drumstick shankle bacon. Pastrami picanha pork loin meatball bresaola meatloaf frankfurter spare ribs leberkas kielbasa chicken shankle. Pork ground round tenderloin beef kevin pork loin tail cow tongue ribeye ham prosciutto jowl alcatra. Brisket swine tail landjaeger andouille beef pig beef ribs pastrami kevin bacon.', 21, '2015-02-18 10:37:22', 5),
(12, 'vinn en konduktörskeps!', 'Pork loin chuck short ribs pastrami, landjaeger swine tail tongue beef kielbasa ham ground round. Doner pancetta sausage spare ribs jerky. Swine cow jowl, corned beef ribeye leberkas biltong short loin beef strip steak jerky meatball cupim tenderloin. Short loin kevin pork loin chuck, alcatra venison filet mignon drumstick shankle bacon. Pastrami picanha pork loin meatball bresaola meatloaf frankfurter spare ribs leberkas kielbasa chicken shankle. Pork ground round tenderloin beef kevin pork loin tail cow tongue ribeye ham prosciutto jowl alcatra. Brisket swine tail landjaeger andouille beef pig beef ribs pastrami kevin bacon.', 22, '2015-02-18 10:38:02', 5);

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `categories`
--
ALTER TABLE `categories`
 ADD PRIMARY KEY (`id`);

--
-- Index för tabell `images`
--
ALTER TABLE `images`
 ADD PRIMARY KEY (`iid`), ADD KEY `user_id` (`user_id`);

--
-- Index för tabell `menu_links`
--
ALTER TABLE `menu_links`
 ADD PRIMARY KEY (`ml_id`), ADD KEY `plid` (`plid`);

--
-- Index för tabell `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`pid`), ADD KEY `img_id` (`img_id`), ADD KEY `catId` (`catId`);

--
-- AUTO_INCREMENT för dumpade tabeller
--

--
-- AUTO_INCREMENT för tabell `categories`
--
ALTER TABLE `categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT för tabell `images`
--
ALTER TABLE `images`
MODIFY `iid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT för tabell `menu_links`
--
ALTER TABLE `menu_links`
MODIFY `ml_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT för tabell `pages`
--
ALTER TABLE `pages`
MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- Restriktioner för dumpade tabeller
--

--
-- Restriktioner för tabell `menu_links`
--
ALTER TABLE `menu_links`
ADD CONSTRAINT `menu_links_ibfk_1` FOREIGN KEY (`plid`) REFERENCES `menu_links` (`ml_id`),
ADD CONSTRAINT `menu_links_ibfk_2` FOREIGN KEY (`plid`) REFERENCES `menu_links` (`ml_id`),
ADD CONSTRAINT `menu_links_ibfk_3` FOREIGN KEY (`plid`) REFERENCES `menu_links` (`ml_id`);

--
-- Restriktioner för tabell `pages`
--
ALTER TABLE `pages`
ADD CONSTRAINT `pages_ibfk_2` FOREIGN KEY (`img_id`) REFERENCES `images` (`iid`),
ADD CONSTRAINT `pages_ibfk_4` FOREIGN KEY (`catId`) REFERENCES `categories` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
